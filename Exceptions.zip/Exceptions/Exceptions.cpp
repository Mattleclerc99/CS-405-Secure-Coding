// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>
#include <stdexcept>

// Custom exception class derived from std::exception
class CustomException : public std::exception {
public:
    const char* what() const noexcept override {
        return "Custom exception occurred!";
    }
};

bool do_even_more_custom_application_logic() {
    // TODO: Throw any standard exception
    // MRL 1/27/25: Threw a std::runtime_error exception as an example.
    throw std::runtime_error("Standard exception thrown from do_even_more_custom_application_logic!");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}

void do_custom_application_logic() {
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    // MRL 1/27/25: Added a try-catch block to handle std::exception and log the exception's what() message.
    std::cout << "Running Custom Application Logic." << std::endl;

    try {
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) {
        std::cerr << "Exception caught: " << e.what() << std::endl;
    }

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explicitly in main
    // MRL 1/27/25: Threw a CustomException at the end of this function.
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den) {
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    // MRL 1/27/25: Added logic to throw std::invalid_argument for divide by zero errors.
    if (den == 0) {
        throw std::invalid_argument("Division by zero is undefined.");
    }
    return (num / den);
}

void do_division() noexcept {
    // TODO: Create an exception handler to capture ONLY the exception thrown
    //  by divide.
    // MRL 1/27/25: Wrapped divide call in a try-catch block to specifically catch std::invalid_argument.
    float numerator = 10.0f;
    float denominator = 0;

    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& e) {
        std::cerr << "Division error: " << e.what() << std::endl;
    }
}

int main() {
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.
    // MRL 1/27/25: Wrapped the entire main function in a try-catch block to handle all specified exceptions.

    try {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& e) {
        std::cerr << "Custom exception caught: " << e.what() << std::endl;
    }
    catch (const std::exception& e) {
        std::cerr << "Standard exception caught: " << e.what() << std::endl;
    }
    catch (...) {
        std::cerr << "An unknown error occurred!" << std::endl;
    }

    return 0;
}
