// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

// Encrypt or decrypt a source string using the provided key
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    const auto key_length = key.length();
    const auto source_length = source.length();

    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    for (size_t i = 0; i < source_length; ++i)
    {
        // TODO: student need to change the next line from output[i] = source[i]
        // MRL: Transformed character using XOR with the key, wrapped by modulo
        output[i] = source[i] ^ key[i % key_length];
    }

    assert(output.length() == source_length);

    return output;
}

// Read the content of a file into a string
std::string read_file(const std::string& filename)
{
    std::ifstream file(filename);
    if (!file.is_open())
    {
        throw std::runtime_error("Could not open file " + filename);
    }

    std::stringstream buffer;
    buffer << file.rdbuf();

    // TODO: implement loading the file into a string
    // MRL: File content loaded into a string and returned
    return buffer.str();
}

// Extract the student's name from the string data (first line of the file)
std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // TODO: Extract the student's name from the first line of the data
    size_t pos = string_data.find('\n');
    if (pos != std::string::npos)
    {
        // MRL: Found newline and extracted the substring as the student's name
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

// Save data to a file in the specified format
void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    std::ofstream file(filename);
    if (!file.is_open())
    {
        throw std::runtime_error("Could not open file " + filename);
    }

    // TODO: implement file saving
    // MRL: File saving implemented in the specified format
    std::time_t t = std::time(nullptr);
    std::tm tm;

    // Use localtime_s instead of localtime
    localtime_s(&tm, &t);

    file << student_name << '\n';
    file << std::put_time(&tm, "%Y-%m-%d") << '\n';
    file << key << '\n';
    file << data << '\n';
    file.close();
}

int main()
{
    std::cout << "Encryption Decryption Test!" << std::endl;

    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrypteddatafile.txt";
    const std::string source_string = read_file(file_name);
    const std::string key = "password";

    // TODO: Retrieve the student's name from the source string
    // MRL: Called `get_student_name` to get the name from the input data
    const std::string student_name = get_student_name(source_string);

    // TODO: Encrypt the source string with the provided key
    // MRL: Encrypted the input string using the `encrypt_decrypt` function
    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    // TODO: Save the encrypted string to the specified file
    // MRL: Called `save_data_file` to save the encrypted data
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    // TODO: Decrypt the encrypted string with the provided key
    // MRL: Decrypted the encrypted string using the `encrypt_decrypt` function
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    // TODO: Save the decrypted string to the specified file
    // MRL: Called `save_data_file` to save the decrypted data
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    std::cout << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;

    return 0;
}


// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
